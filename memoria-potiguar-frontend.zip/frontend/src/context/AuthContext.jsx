import { createContext, useContext, useEffect, useMemo, useState } from 'react'
import { getCurrentUser, loginUser, registerUser } from '../api'

const AuthContext = createContext(null)
const TOKEN_KEY = 'memoria_potiguar_token'
const USER_KEY = 'memoria_potiguar_user'

export function AuthProvider({ children }) {
  const [token, setToken] = useState(() => localStorage.getItem(TOKEN_KEY))
  const [user, setUser] = useState(() => {
    try {
      return JSON.parse(localStorage.getItem(USER_KEY) ?? 'null')
    } catch {
      return null
    }
  })
  const [loading, setLoading] = useState(Boolean(token))

  useEffect(() => {
    let active = true

    async function validateToken() {
      if (!token) {
        setLoading(false)
        return
      }

      try {
        const currentUser = await getCurrentUser(token)
        if (!active) return
        setUser(currentUser)
        localStorage.setItem(USER_KEY, JSON.stringify(currentUser))
      } catch {
        if (!active) return
        localStorage.removeItem(TOKEN_KEY)
        localStorage.removeItem(USER_KEY)
        setToken(null)
        setUser(null)
      } finally {
        if (active) setLoading(false)
      }
    }

    validateToken()
    return () => { active = false }
  }, [token])

  async function login(email, senha) {
    const data = await loginUser(email, senha)
    localStorage.setItem(TOKEN_KEY, data.access_token)
    setToken(data.access_token)
    const currentUser = await getCurrentUser(data.access_token)
    localStorage.setItem(USER_KEY, JSON.stringify(currentUser))
    setUser(currentUser)
    return currentUser
  }

  async function register(payload) {
    return registerUser(payload)
  }

  function logout() {
    localStorage.removeItem(TOKEN_KEY)
    localStorage.removeItem(USER_KEY)
    setToken(null)
    setUser(null)
  }

  const value = useMemo(() => ({
    token,
    user,
    loading,
    isAuthenticated: Boolean(token && user),
    login,
    register,
    logout,
  }), [token, user, loading])

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (!context) throw new Error('useAuth deve ser usado dentro de AuthProvider')
  return context
}
