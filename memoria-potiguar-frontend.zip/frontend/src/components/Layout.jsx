import { NavLink, Link, useNavigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'

export default function Layout({ children }) {
  const { user, logout } = useAuth()
  const navigate = useNavigate()

  function handleLogout() {
    logout()
    navigate('/login')
  }

  return (
    <div className="app-shell">
      <header className="topbar">
        <Link to="/" className="brand">
          <span className="brand-mark">MP</span>
          <span>
            <strong>Memória Potiguar</strong>
            <small>Cultura, sabores e histórias do RN</small>
          </span>
        </Link>

        <nav className="nav-links" aria-label="Navegação principal">
          <NavLink to="/">Início</NavLink>
          <NavLink to="/gastronomico">Gastronômico</NavLink>
          <NavLink to="/historico">Histórico</NavLink>
          {user && <NavLink to="/perfil">Perfil</NavLink>}
        </nav>

        <div className="nav-user">
          {user ? (
            <>
              <span className="user-chip">Olá, {user.nome.split(' ')[0]}</span>
              <button className="button button-small button-ghost" onClick={handleLogout}>Sair</button>
            </>
          ) : (
            <>
              <Link className="button button-small button-ghost" to="/login">Entrar</Link>
              <Link className="button button-small" to="/cadastro">Criar conta</Link>
            </>
          )}
        </div>
      </header>
      <main>{children}</main>
      <footer className="footer">Memória Potiguar • Projeto acadêmico</footer>
    </div>
  )
}
