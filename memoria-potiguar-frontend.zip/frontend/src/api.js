const API_URL = import.meta.env.VITE_API_URL ?? ''

async function parseResponse(response) {
  const contentType = response.headers.get('content-type') ?? ''
  const body = contentType.includes('application/json')
    ? await response.json()
    : await response.text()

  if (!response.ok) {
    const message = typeof body === 'object' && body?.detail
      ? body.detail
      : 'Não foi possível concluir a solicitação.'
    throw new Error(message)
  }

  return body
}

export async function registerUser(payload) {
  const response = await fetch(`${API_URL}/auth/register`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  })
  return parseResponse(response)
}

export async function loginUser(email, senha) {
  const formData = new URLSearchParams()
  formData.set('username', email)
  formData.set('password', senha)

  const response = await fetch(`${API_URL}/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: formData,
  })
  return parseResponse(response)
}

export async function getCurrentUser(token) {
  const response = await fetch(`${API_URL}/users/me`, {
    headers: {
      Authorization: `Bearer ${token}`,
    },
  })
  return parseResponse(response)
}
