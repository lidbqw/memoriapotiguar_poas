import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'

export default function Cadastro() {
  const { register } = useAuth()
  const navigate = useNavigate()
  const [form, setForm] = useState({ nome: '', email: '', senha: '', confirmarSenha: '' })
  const [error, setError] = useState('')
  const [success, setSuccess] = useState('')
  const [loading, setLoading] = useState(false)

  async function handleSubmit(event) {
    event.preventDefault()
    setError('')
    setSuccess('')
    if (form.senha !== form.confirmarSenha) return setError('As senhas não coincidem.')

    setLoading(true)
    try {
      await register({ nome: form.nome, email: form.email, senha: form.senha })
      setSuccess('Conta criada! Redirecionando para o login...')
      setTimeout(() => navigate('/login'), 800)
    } catch (err) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="auth-page">
      <section className="auth-intro signup-intro">
        <span className="eyebrow">FAÇA PARTE</span>
        <h1>Guardar memória também é cuidar de quem veio antes.</h1>
        <p>Crie sua conta e tenha um espaço personalizado para acompanhar sua jornada.</p>
        <div className="benefit-list">
          <span>✓ Perfil personalizado</span>
          <span>✓ Acesso ao seu histórico</span>
          <span>✓ Experiência feita para você</span>
        </div>
      </section>
      <form className="auth-card" onSubmit={handleSubmit}>
        <div className="form-heading">
          <span className="card-icon">✨</span>
          <h2>Criar conta</h2>
          <p>É rapidinho. Só precisamos de três informações.</p>
        </div>
        {error && <div className="alert error">{error}</div>}
        {success && <div className="alert success">{success}</div>}
        <label>
          Nome
          <input type="text" required maxLength={255} value={form.nome} onChange={(e) => setForm({ ...form, nome: e.target.value })} placeholder="Seu nome completo" />
        </label>
        <label>
          E-mail
          <input type="email" required value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} placeholder="voce@email.com" />
        </label>
        <label>
          Senha
          <input type="password" required minLength={6} value={form.senha} onChange={(e) => setForm({ ...form, senha: e.target.value })} placeholder="Mínimo de 6 caracteres" />
        </label>
        <label>
          Confirmar senha
          <input type="password" required minLength={6} value={form.confirmarSenha} onChange={(e) => setForm({ ...form, confirmarSenha: e.target.value })} placeholder="Digite a senha novamente" />
        </label>
        <button className="button button-full" disabled={loading}>{loading ? 'Criando...' : 'Criar minha conta'}</button>
        <p className="form-footer">Já possui uma conta? <Link to="/login">Entrar</Link></p>
      </form>
    </div>
  )
}
