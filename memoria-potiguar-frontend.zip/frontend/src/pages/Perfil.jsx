import { useAuth } from '../context/AuthContext'

export default function Perfil() {
  const { user } = useAuth()
  const date = user?.created_at ? new Date(user.created_at).toLocaleDateString('pt-BR') : '—'

  return (
    <div className="page-content narrow">
      <section className="page-header">
        <span className="eyebrow">MINHA CONTA</span>
        <h1>Perfil</h1>
        <p>Dados devolvidos pelo endpoint protegido <code>/users/me</code>.</p>
      </section>
      <section className="profile-card">
        <div className="avatar">{user.nome.charAt(0).toUpperCase()}</div>
        <div className="profile-main">
          <h2>{user.nome}</h2>
          <p>{user.email}</p>
        </div>
        <div className="profile-data">
          <div><span>ID</span><strong>{user.id ?? '—'}</strong></div>
          <div><span>Cadastro</span><strong>{date}</strong></div>
        </div>
      </section>
    </div>
  )
}
