import { Link } from 'react-router-dom'

export default function NotFound() {
  return (
    <div className="empty-state">
      <div className="empty-icon">🌵</div>
      <h1>404</h1>
      <p>Essa página pegou uma estrada diferente.</p>
      <Link className="button" to="/">Voltar ao início</Link>
    </div>
  )
}
