import { Link } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'

export default function Historico() {
  const { user } = useAuth()

  return (
    <div className="page-content">
      <section className="page-header">
        <span className="eyebrow">SUA JORNADA</span>
        <h1>Histórico</h1>
        <p>Um espaço pronto para receber as interações do usuário conforme o backend ganhar novos módulos.</p>
      </section>

      {user ? (
        <section className="timeline">
          <article className="timeline-item">
            <span className="timeline-dot">👤</span>
            <div>
              <small>AGORA</small>
              <h3>Conta conectada</h3>
              <p>Você está autenticado como <strong>{user.email}</strong>.</p>
            </div>
          </article>
          <article className="timeline-item muted">
            <span className="timeline-dot">📚</span>
            <div>
              <small>PRÓXIMO PASSO</small>
              <h3>Mais memórias estão a caminho</h3>
              <p>O histórico pode receber favoritos, visitas, avaliações ou registros de conteúdo quando esses endpoints forem criados.</p>
            </div>
          </article>
        </section>
      ) : (
        <div className="empty-state">
          <div className="empty-icon">🗂️</div>
          <h2>Entre para ver seu histórico</h2>
          <p>Seu histórico será associado à conta depois do login.</p>
          <Link className="button" to="/login">Entrar</Link>
        </div>
      )}
    </div>
  )
}
