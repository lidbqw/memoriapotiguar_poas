import { Link } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'

const highlights = [
  { icon: '🍲', title: 'Gastronomia', text: 'Descubra sabores, pratos e tradições que carregam a identidade potiguar.' },
  { icon: '📜', title: 'Memória', text: 'Conheça histórias e referências que ajudam a preservar a cultura do Rio Grande do Norte.' },
  { icon: '🧭', title: 'Explore', text: 'Navegue pelos conteúdos e monte seu próprio caminho pela memória potiguar.' },
]

export default function Home() {
  const { user } = useAuth()

  return (
    <div>
      <section className="hero">
        <div className="hero-copy">
          <span className="eyebrow">RIO GRANDE DO NORTE</span>
          <h1>A memória de um povo mora nas histórias que a gente escolhe guardar.</h1>
          <p>
            Um espaço para descobrir, valorizar e compartilhar elementos da cultura potiguar — dos sabores às histórias que atravessam gerações.
          </p>
          <div className="hero-actions">
            <Link className="button" to="/gastronomico">Explorar gastronomia</Link>
            {!user && <Link className="button button-light" to="/cadastro">Entrar para a comunidade</Link>}
          </div>
        </div>
        <div className="hero-card">
          <div className="hero-art">🌵</div>
          <span>Identidade potiguar</span>
          <strong>raízes, sabores e lembranças</strong>
        </div>
      </section>

      <section className="section">
        <div className="section-heading">
          <span className="eyebrow">POR ONDE COMEÇAR</span>
          <h2>Conheça a essência do projeto</h2>
        </div>
        <div className="card-grid">
          {highlights.map((item) => (
            <article className="info-card" key={item.title}>
              <span className="card-icon">{item.icon}</span>
              <h3>{item.title}</h3>
              <p>{item.text}</p>
            </article>
          ))}
        </div>
      </section>
    </div>
  )
}
