const foods = [
  { emoji: '🥥', title: 'Cocada', text: 'Doce feito à base de coco, presença clássica nos sabores do Nordeste.' },
  { emoji: '🌽', title: 'Tapioca', text: 'Versátil, afetiva e democrática: vai do café da manhã ao lanche da tarde.' },
  { emoji: '🥩', title: 'Carne de sol', text: 'Um dos ingredientes mais emblemáticos da culinária sertaneja.' },
  { emoji: '🍚', title: 'Baião de dois', text: 'Arroz e feijão se encontram em um prato cheio de memória e sabor.' },
  { emoji: '🐟', title: 'Peixes e frutos do mar', text: 'A costa potiguar também aparece na mesa, com preparos simples e marcantes.' },
  { emoji: '🍠', title: 'Macaxeira', text: 'Ingrediente cotidiano que vira acompanhamento, purê, bolo e muito mais.' },
]

export default function Gastronomico() {
  return (
    <div className="page-content">
      <section className="page-header">
        <span className="eyebrow">SABORES DO RN</span>
        <h1>Gastronomia Potiguar</h1>
        <p>Comida também é documento: cada receita conta um pedaço da história de um lugar.</p>
      </section>
      <div className="food-grid">
        {foods.map((food) => (
          <article className="food-card" key={food.title}>
            <div className="food-emoji">{food.emoji}</div>
            <div>
              <span className="tag">TRADIÇÃO</span>
              <h2>{food.title}</h2>
              <p>{food.text}</p>
            </div>
          </article>
        ))}
      </div>
      <div className="notice">
        <strong>Nota:</strong> este catálogo está preparado como conteúdo inicial do frontend. Para deixar os pratos dinâmicos, basta adicionar um endpoint no FastAPI e consumir a API aqui.
      </div>
    </div>
  )
}
