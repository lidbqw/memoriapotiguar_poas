import { useEffect, useState } from 'react'
import { Link, useLocation, useNavigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'

export default function Login() {
  const { login, isAuthenticated } = useAuth()
  const navigate = useNavigate()
  const location = useLocation()
  const [form, setForm] = useState({ email: '', senha: '' })
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    if (isAuthenticated) navigate('/', { replace: true })
  }, [isAuthenticated, navigate])

  async function handleSubmit(event) {
    event.preventDefault()
    setError('')
    setLoading(true)
    try {
      await login(form.email, form.senha)
      navigate(location.state?.from || '/', { replace: true })
    } catch (err) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="auth-page">
      <section className="auth-intro">
        <span className="eyebrow">BEM-VINDE DE VOLTA</span>
        <h1>Suas memórias, em um só lugar.</h1>
        <p>Entre para continuar sua jornada pela cultura potiguar.</p>
        <div className="auth-quote">“Cultura é aquilo que fica quando a gente lembra de onde veio.”</div>
      </section>
      <form className="auth-card" onSubmit={handleSubmit}>
        <div className="form-heading">
          <span className="card-icon">🔐</span>
          <h2>Entrar</h2>
          <p>Acesse sua conta do Memória Potiguar.</p>
        </div>

        {error && <div className="alert error">{error}</div>}

        <label>
          E-mail
          <input type="email" required value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} placeholder="voce@email.com" />
        </label>
        <label>
          Senha
          <input type="password" required minLength={6} value={form.senha} onChange={(e) => setForm({ ...form, senha: e.target.value })} placeholder="••••••••" />
        </label>
        <button className="button button-full" disabled={loading}>{loading ? 'Entrando...' : 'Entrar'}</button>
        <p className="form-footer">Ainda não tem conta? <Link to="/cadastro">Cadastre-se</Link></p>
      </form>
    </div>
  )
}
