# Frontend — Memória Potiguar

Frontend React + Vite complementar ao backend FastAPI.

**Posicionamento:** esta pasta deve ficar ao lado de `backend`, porque o `main.py` calcula o diretório com `Path(__file__).resolve().parent.parent`.

## Estrutura

- `src/api.js`: integração com `/auth/register`, `/auth/login` e `/users/me`.
- `src/context/AuthContext.jsx`: sessão JWT no `localStorage`.
- `src/pages`: telas do projeto.
- `src/components`: layout e proteção de rotas.
- `vite.config.js`: gera o build em `frontend/build`, como o `main.py` espera.
- `login.html`, `cadastro.html`, `gastronomico.html`, `historico.html`, `index.html`: páginas compatíveis com os endpoints `FileResponse` já existentes no FastAPI.

## Desenvolvimento

```bash
npm install
npm run dev
```

Com backend em outra porta, configure `VITE_API_URL=http://127.0.0.1:8000` no arquivo `.env.local`.

## Produção / integração com FastAPI

```bash
npm run build
```

Isso cria `frontend/build`. Depois, suba o FastAPI normalmente. O `main.py` já está preparado para montar essa pasta na raiz.

## Observação importante

O backend fornecido possui apenas endpoints de autenticação e usuário. Por isso, as telas de Gastronomia e Histórico vêm com conteúdo inicial de frontend; para dados reais, basta criar os endpoints correspondentes e ligar essas páginas ao `src/api.js`.
